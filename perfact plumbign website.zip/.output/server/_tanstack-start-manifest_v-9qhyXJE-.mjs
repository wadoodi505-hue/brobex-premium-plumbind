//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-9qhyXJE-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/about-brobex",
			"/contact",
			"/faq",
			"/reviews",
			"/why-brobax",
			"/services/$slug",
			"/services/"
		],
		preloads: ["/assets/index-COcDnMfe.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-COcDnMfe.js"
		} }]
	},
	"/": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-cGRSiVi_.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/Services-BBsVGn07.js",
			"/assets/arrow-up-right-CoDQenRe.js",
			"/assets/Testimonials-DeqUfia3.js",
			"/assets/shield-check-uMptmlF2.js",
			"/assets/sparkles-B0W54sb5.js",
			"/assets/Emergency-B-E49Gbp.js",
			"/assets/WhyBrobax-DC7q3Fbp.js"
		]
	},
	"/about": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-BHY7E40g.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/clock-B_2qa6tp.js",
			"/assets/shield-check-uMptmlF2.js",
			"/assets/PageHeader-BSBNU8WX.js",
			"/assets/Emergency-B-E49Gbp.js"
		]
	},
	"/about-brobex": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/about-brobex.tsx",
		children: void 0,
		preloads: [
			"/assets/about-brobex-GGvRAul_.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/sparkles-B0W54sb5.js",
			"/assets/PageHeader-BSBNU8WX.js"
		]
	},
	"/contact": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact--3DTRzAr.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/PageHeader-BSBNU8WX.js"
		]
	},
	"/faq": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/faq.tsx",
		children: void 0,
		preloads: [
			"/assets/faq-pwLP2UTA.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/PageHeader-BSBNU8WX.js",
			"/assets/Emergency-B-E49Gbp.js"
		]
	},
	"/reviews": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/reviews.tsx",
		children: void 0,
		preloads: [
			"/assets/reviews-CWLXlFJd.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/Testimonials-DeqUfia3.js",
			"/assets/PageHeader-BSBNU8WX.js",
			"/assets/Emergency-B-E49Gbp.js"
		]
	},
	"/why-brobax": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/why-brobax.tsx",
		children: void 0,
		preloads: [
			"/assets/why-brobax-DDHFVoem.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/PageHeader-BSBNU8WX.js",
			"/assets/Emergency-B-E49Gbp.js",
			"/assets/WhyBrobax-DC7q3Fbp.js"
		]
	},
	"/services/$slug": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/services.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/services._slug-9aGNnMg-.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/arrow-up-right-CoDQenRe.js",
			"/assets/clock-B_2qa6tp.js"
		]
	},
	"/services/": {
		filePath: "D:/code/direct clint hunting/brobex_plumbing.lovable.app/src/routes/services.index.tsx",
		children: void 0,
		preloads: [
			"/assets/services.index-RxiZuKa2.js",
			"/assets/SiteLayout-BwPwk8v7.js",
			"/assets/Services-BBsVGn07.js",
			"/assets/PageHeader-BSBNU8WX.js",
			"/assets/Emergency-B-E49Gbp.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
