globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/about-BHY7E40g.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1116-pqiXgZBw8R2/nuoMxavImE85430\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 4374,
		"path": "../public/assets/about-BHY7E40g.js"
	},
	"/assets/about-brobex-GGvRAul_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2077-kktcdRFDjKBAqzxFhxA5g6ViMCw\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 8311,
		"path": "../public/assets/about-brobex-GGvRAul_.js"
	},
	"/assets/arrow-up-right-CoDQenRe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9c-2stAnQOViYORZFeneRyChF0Rik0\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 156,
		"path": "../public/assets/arrow-up-right-CoDQenRe.js"
	},
	"/assets/clock-B_2qa6tp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e-V9JPK7Dm2Eh9Jxp9mwpsfxWfco0\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 158,
		"path": "../public/assets/clock-B_2qa6tp.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-09-02T01:38:06.382Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"1eb8-/xnLMPcjH+8OOHoRiSt4g/6DIhA\"",
		"mtime": "2026-09-02T01:27:35.315Z",
		"size": 7864,
		"path": "../public/favicon.png"
	},
	"/assets/contact--3DTRzAr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17c5-g42iLxN53Ci6OHm/w98e2roEDDs\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 6085,
		"path": "../public/assets/contact--3DTRzAr.js"
	},
	"/assets/Emergency-B-E49Gbp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"810-c/LbyLyet2wHa1xxz3TyJwtX1Qk\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 2064,
		"path": "../public/assets/Emergency-B-E49Gbp.js"
	},
	"/assets/faq-pwLP2UTA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"206-j8fjeQtNwvxoF9q5yVKns/r4+R0\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 518,
		"path": "../public/assets/faq-pwLP2UTA.js"
	},
	"/assets/PageHeader-BSBNU8WX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f8-EyFkaZMdyQLG58wmTwxlL9mgO5w\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 1016,
		"path": "../public/assets/PageHeader-BSBNU8WX.js"
	},
	"/assets/reviews-CWLXlFJd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"247-kixaokewnV+KBAtsgtqredP/6GU\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 583,
		"path": "../public/assets/reviews-CWLXlFJd.js"
	},
	"/assets/emergency-bg-DP6IQDe5.jpg": {
		"type": "image/jpeg",
		"etag": "\"770f-h0dJNJjiKLdI0SzDIENnF8cwcc4\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 30479,
		"path": "../public/assets/emergency-bg-DP6IQDe5.jpg"
	},
	"/assets/routes-cGRSiVi_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ffd-8uBXT/tZZhHTwBs/VbGNv/qO42s\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 12285,
		"path": "../public/assets/routes-cGRSiVi_.js"
	},
	"/assets/Services-BBsVGn07.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"978-hK1uJP4OlPTnZuVPgCGvT64FWPU\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 2424,
		"path": "../public/assets/Services-BBsVGn07.js"
	},
	"/assets/index-COcDnMfe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6f66e-j2oYsuzuzBKRgmQQDlCb6wlWmMk\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 456302,
		"path": "../public/assets/index-COcDnMfe.js"
	},
	"/assets/services.index-RxiZuKa2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27a-ozh+vpNM5AIGASS4ONkgzBnjanY\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 634,
		"path": "../public/assets/services.index-RxiZuKa2.js"
	},
	"/assets/hero-plumbing-YdFQy2X8.jpg": {
		"type": "image/jpeg",
		"etag": "\"288a7-GlsVSEQ3l3WkLV/1PUPBk07pARo\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 166055,
		"path": "../public/assets/hero-plumbing-YdFQy2X8.jpg"
	},
	"/assets/services._slug-9aGNnMg-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1337-WosDOKsvW2XW3OMImZc/MHysekw\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 4919,
		"path": "../public/assets/services._slug-9aGNnMg-.js"
	},
	"/assets/shield-check-uMptmlF2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"135-JFpwmzXyKyhVw/eGAbUGqHzYcdc\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 309,
		"path": "../public/assets/shield-check-uMptmlF2.js"
	},
	"/assets/SiteLayout-BwPwk8v7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27d3-tYG+eNfZC0ZnYU47ffrP180jIjE\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 10195,
		"path": "../public/assets/SiteLayout-BwPwk8v7.js"
	},
	"/assets/sparkles-B0W54sb5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e3-tdSbjJCakva5qkE46w6wllCD5aM\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 483,
		"path": "../public/assets/sparkles-B0W54sb5.js"
	},
	"/assets/Testimonials-DeqUfia3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eaf-4xZJeStoLJ6JNtSEUf5KwVYbigQ\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 3759,
		"path": "../public/assets/Testimonials-DeqUfia3.js"
	},
	"/assets/styles-BsIbgmcy.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16f23-gLuHNOMK3km9kHkAmn4ftFR4kiI\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 93987,
		"path": "../public/assets/styles-BsIbgmcy.css"
	},
	"/assets/why-brobax-CD3cl9Fo.jpg": {
		"type": "image/jpeg",
		"etag": "\"21457-T2F49NXtSDHmv2z5deuKASGESGI\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 136279,
		"path": "../public/assets/why-brobax-CD3cl9Fo.jpg"
	},
	"/assets/brobex-logo-DuB_-XK_.png": {
		"type": "image/png",
		"etag": "\"17df24-P4Y17HP+6ovEuMjeycuufEKQcyo\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 1564452,
		"path": "../public/assets/brobex-logo-DuB_-XK_.png"
	},
	"/assets/why-brobax-DDHFVoem.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23b-zqnF1gWbJKSVyL+7wOB5BjaCsFA\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 571,
		"path": "../public/assets/why-brobax-DDHFVoem.js"
	},
	"/assets/WhyBrobax-DC7q3Fbp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c62-XFWb9Q4UqkI7drobjYItkoRDtGs\"",
		"mtime": "2026-09-02T09:20:42.493Z",
		"size": 3170,
		"path": "../public/assets/WhyBrobax-DC7q3Fbp.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_CY3bhj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_CY3bhj
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
