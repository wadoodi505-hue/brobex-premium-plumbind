import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { M as Clock, c as ShieldCheck, d as Ruler, k as Eye, w as HeartHandshake, z as BadgeCheck } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-BFupRpb9.mjs";
import { t as PageHeader } from "./PageHeader-q3pUGuA6.mjs";
import { t as Emergency } from "./Emergency--jNbWuPk.mjs";
import { u as Reveal } from "./router-DLSf9tlB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Buutunh9.js
var import_jsx_runtime = require_jsx_runtime();
var pillars = [
	{
		icon: BadgeCheck,
		title: "Professional Workmanship",
		text: "Work completed to a considered, tidy standard on every visit."
	},
	{
		icon: Clock,
		title: "Fast Response",
		text: "Prompt replies and efficient scheduling when something goes wrong."
	},
	{
		icon: Eye,
		title: "Transparent Communication",
		text: "Clear explanations of the issue and the work before we begin."
	},
	{
		icon: ShieldCheck,
		title: "Reliable Service",
		text: "Dependable arrival times and solutions built to last."
	},
	{
		icon: Ruler,
		title: "Attention To Detail",
		text: "Finishing, sealing, and testing checked before we leave."
	},
	{
		icon: HeartHandshake,
		title: "Customer-First Approach",
		text: "Your home, comfort, and time respected throughout."
	}
];
var stats = [
	"Fast Response",
	"Professional Service",
	"Reliable Solutions",
	"Customer Focused"
];
function Trust() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "about",
		className: "relative overflow-hidden py-24 lg:py-32",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "depth-bg pointer-events-none absolute inset-0 opacity-70",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-7xl px-5 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "mx-auto max-w-2xl text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "About BroBax"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-4 text-4xl sm:text-5xl",
							children: ["Built on trust, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-metal",
								children: "finished with care"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-muted-foreground",
							children: "BroBax is a premium plumbing and heating service focused on doing fewer things exceptionally well — precise work, honest advice, and a service experience that feels effortless."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "mt-14",
					delay: 80,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "glass grid grid-cols-2 gap-px overflow-hidden rounded-2xl lg:grid-cols-4",
						children: stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "px-6 py-8 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl text-brass-soft sm:text-3xl",
								children: stat.split(" ")[0]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[0.68rem] tracking-[0.2em] uppercase text-muted-foreground",
								children: stat.split(" ").slice(1).join(" ")
							})]
						}, stat))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
					children: pillars.map((pillar, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i % 3 * 90,
						from: i % 2 === 0 ? "left" : "right",
						className: "h-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "lux-card sheen h-full rounded-2xl p-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(pillar.icon, {
									className: "h-5 w-5 text-brass",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 text-xl",
									children: pillar.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2.5 text-sm leading-relaxed text-muted-foreground",
									children: pillar.text
								})
							]
						})
					}, pillar.title))
				})
			]
		})]
	});
}
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "About BroBax",
			title: "A service brand,",
			accent: "not just a trade call",
			intro: "BroBax was built around a simple idea: plumbing should feel like a premium service. Considered diagnosis, respectful work in your home, and honest answers before anything begins."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trust, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Emergency, {})
	] });
}
//#endregion
export { AboutPage as component };
