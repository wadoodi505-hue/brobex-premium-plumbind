import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as SiteLayout } from "./SiteLayout-BFupRpb9.mjs";
import { t as PageHeader } from "./PageHeader-q3pUGuA6.mjs";
import { t as Emergency } from "./Emergency--jNbWuPk.mjs";
import { t as Services } from "./Services-M8P6MgPe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.index-scRqm3zT.js
var import_jsx_runtime = require_jsx_runtime();
function ServicesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Our Services",
			title: "Plumbing & heating,",
			accent: "done properly",
			intro: "Every service follows the same standard: diagnose the real cause, explain the work and the cost, then finish it to a level we would accept in our own home. Select a service to see exactly what it covers."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, { heading: false }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Emergency, {})
	] });
}
//#endregion
export { ServicesPage as component };
