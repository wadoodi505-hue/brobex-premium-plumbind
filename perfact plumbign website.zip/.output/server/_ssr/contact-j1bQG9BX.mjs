import { n as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { b as Mail, l as Send, m as Phone, v as MessageCircle } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-BFupRpb9.mjs";
import { t as PageHeader } from "./PageHeader-q3pUGuA6.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as BRAND, o as LuxButton, u as Reveal } from "./router-DLSf9tlB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-j1bQG9BX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var serviceTypes = [
	"Emergency Plumbing",
	"Drain Cleaning",
	"Leak Detection & Repair",
	"Water Heater Services",
	"Boiler & Heating Services",
	"Pipe Repair & Replacement",
	"Bathroom Plumbing",
	"Kitchen Plumbing",
	"Fixture Installation",
	"Preventive Maintenance"
];
var fieldClass = "w-full rounded-xl border border-input bg-surface/60 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 transition-colors duration-300 focus:border-brass/60 focus:outline-none focus:ring-2 focus:ring-ring";
function Contact() {
	const [sending, setSending] = (0, import_react.useState)(false);
	function handleSubmit(event) {
		event.preventDefault();
		const form = event.currentTarget;
		const data = new FormData(form);
		setSending(true);
		const body = [
			`Name: ${data.get("name")}`,
			`Phone: ${data.get("phone")}`,
			`Email: ${data.get("email")}`,
			`Service Type: ${data.get("service")}`,
			"",
			String(data.get("message") ?? "")
		].join("\n");
		window.location.href = `mailto:${BRAND.email}?subject=${encodeURIComponent(`Service request — ${data.get("service")}`)}&body=${encodeURIComponent(body)}`;
		toast.success("Opening your email app to send the request to BroBax.");
		form.reset();
		setSending(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "contact",
		className: "relative overflow-hidden py-24 lg:py-32",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "depth-bg pointer-events-none absolute inset-0",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Contact"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 text-4xl sm:text-5xl",
					children: ["Request a service ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-metal",
						children: "with BroBax"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-muted-foreground",
					children: "Tell us what you need and we will follow up promptly with next steps and a clear plan for the work."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: BRAND.phoneHref,
							className: "lux-card flex items-center gap-4 rounded-2xl p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-brass/30 bg-brass/10 text-brass",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "h-4 w-4",
									"aria-hidden": "true"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "eyebrow block",
									children: "Phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block font-display text-2xl text-brass-soft",
									children: BRAND.phoneDisplay
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: BRAND.whatsappHref,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "lux-card flex items-center gap-4 rounded-2xl p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-brass/30 bg-brass/10 text-brass",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
									className: "h-4 w-4",
									"aria-hidden": "true"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "eyebrow block",
									children: "WhatsApp"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block font-display text-2xl text-brass-soft",
									children: BRAND.whatsappDisplay
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `mailto:${BRAND.email}`,
							className: "lux-card flex items-center gap-4 rounded-2xl p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-brass/30 bg-brass/10 text-brass",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "h-4 w-4",
									"aria-hidden": "true"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "eyebrow block",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block truncate text-base text-foreground/90",
									children: BRAND.email
								})]
							})]
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 100,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "glass rounded-[1.5rem] p-6 sm:p-9",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "name",
									className: "eyebrow mb-2 block",
									children: "Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "name",
									name: "name",
									required: true,
									className: fieldClass,
									placeholder: "Full name"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "phone",
									className: "eyebrow mb-2 block",
									children: "Phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "phone",
									name: "phone",
									type: "tel",
									required: true,
									className: fieldClass,
									placeholder: "Best contact number"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "email",
										className: "eyebrow mb-2 block",
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "email",
										name: "email",
										type: "email",
										required: true,
										className: fieldClass,
										placeholder: "you@example.com"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "service",
										className: "eyebrow mb-2 block",
										children: "Service Type"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "service",
										name: "service",
										required: true,
										defaultValue: "",
										className: fieldClass,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											disabled: true,
											children: "Select a service"
										}), serviceTypes.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: service,
											className: "bg-surface",
											children: service
										}, service))]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "message",
										className: "eyebrow mb-2 block",
										children: "Message"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: "message",
										name: "message",
										rows: 5,
										required: true,
										className: `${fieldClass} resize-none`,
										placeholder: "Describe the issue or the work you need"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LuxButton, {
							type: "submit",
							disabled: sending,
							className: "mt-7 w-full sm:w-auto",
							children: ["Request Service", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 transition-transform duration-500 group-hover:translate-x-0.5" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-xs text-muted-foreground",
							children: [
								"Submitting opens your email app with the details pre-filled for ",
								BRAND.email,
								"."
							]
						})
					]
				})
			})]
		})]
	});
}
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Contact",
		title: "Tell us what you need,",
		accent: "we'll handle the rest",
		intro: "Call, WhatsApp, email, or send the form below. Urgent issues are prioritised, and every request gets a clear next step."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {})] });
}
//#endregion
export { ContactPage as component };
