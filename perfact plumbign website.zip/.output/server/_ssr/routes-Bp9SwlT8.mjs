import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { B as ArrowUpRight, D as FileText, I as CalendarCheck, L as BellRing, N as ClipboardList, S as Leaf, T as Gauge, a as Sparkles, c as ShieldCheck, h as PhoneCall, m as Phone, n as Wrench } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-BFupRpb9.mjs";
import { t as Emergency } from "./Emergency--jNbWuPk.mjs";
import { a as BRAND, c as LuxRouteLink, s as LuxLink, u as Reveal } from "./router-DLSf9tlB.mjs";
import { t as Testimonials } from "./Testimonials-Cb6vAj-C.mjs";
import { t as Services } from "./Services-M8P6MgPe.mjs";
import { t as WhyBrobax } from "./WhyBrobax-D95JAT2w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bp9SwlT8.js
var import_jsx_runtime = require_jsx_runtime();
var hero_plumbing_default = "/assets/hero-plumbing-YdFQy2X8.jpg";
var markers = [
	"Fast Response",
	"Professional Service",
	"Reliable Solutions",
	"Customer Focused"
];
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "home",
		className: "relative overflow-hidden pt-32 pb-20 lg:pt-44 lg:pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "depth-bg pointer-events-none absolute inset-0",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "aurora pointer-events-none absolute -top-40 left-1/2 h-[36rem] w-[36rem] -translate-x-1/2 rounded-full bg-brass/10 blur-[120px]",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "slide-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Premium Plumbing & Heating"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-5 text-[2.6rem] leading-[1.05] sm:text-6xl lg:text-[4.25rem]",
							children: ["Exceptional Plumbing.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-2 block text-metal-shimmer",
								children: "Built Around Your Comfort."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg",
							children: "Professional plumbing and heating solutions delivered with precision, reliability, and exceptional service."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-9 flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LuxRouteLink, {
								to: "/contact",
								children: ["Request a Service", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4 transition-transform duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LuxLink, {
								href: BRAND.phoneHref,
								variant: "outline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "h-4 w-4",
									"aria-hidden": "true"
								}), "Call BroBax"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: BRAND.phoneHref,
							className: "mt-8 inline-flex items-baseline gap-3 transition-opacity hover:opacity-80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "eyebrow",
								children: "Direct line"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-3xl text-brass-soft sm:text-4xl",
								children: BRAND.phoneDisplay
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-10 flex flex-wrap gap-x-6 gap-y-3",
							children: markers.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2 text-xs tracking-widest uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-1 w-1 rounded-full bg-brass",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: m
								})]
							}, m))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "slide-right relative [animation-delay:120ms]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "float-slow sheen relative overflow-hidden rounded-[1.75rem] border border-border shadow-[var(--shadow-lux)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: hero_plumbing_default,
								alt: "Brushed brass wall-mounted faucet and copper pipework in a dark luxury bathroom",
								width: 1600,
								height: 1200,
								fetchPriority: "high",
								className: "h-[22rem] w-full object-cover transition-transform duration-[1400ms] ease-out will-change-transform hover:scale-105 sm:h-[30rem] lg:h-[34rem]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 bg-[linear-gradient(to_top,oklch(0.16_0.008_60/85%),transparent_55%)]",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass absolute bottom-4 left-4 right-4 rounded-2xl p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Precision · Reliability · Transparency"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 text-sm text-foreground/85",
									children: "Every job finished to a standard we would accept in our own home."
								})]
							})
						]
					})
				})]
			})
		]
	});
}
var steps = [
	{
		icon: PhoneCall,
		step: "01",
		title: "Call or Request",
		text: "Tell us what is happening in your own words. We ask a few targeted questions to understand urgency, access, and the likely cause before we travel.",
		detail: "Answered by a person — no automated queue"
	},
	{
		icon: CalendarCheck,
		step: "02",
		title: "Confirmed Arrival",
		text: "You receive a fixed arrival window rather than a vague half-day slot, plus a message before we set off so your day is never on hold.",
		detail: "Emergency calls prioritised same day"
	},
	{
		icon: ClipboardList,
		step: "03",
		title: "Diagnose & Quote",
		text: "We test, inspect, and isolate the real fault, then explain the options and the cost in plain language. Nothing starts before you approve it.",
		detail: "Written price agreed up front"
	},
	{
		icon: Wrench,
		step: "04",
		title: "Repair & Protect",
		text: "The work is completed with quality parts, protective sheeting over your floors and fittings, and a full clean-down when we finish.",
		detail: "Dust sheets and floor protection as standard"
	},
	{
		icon: ShieldCheck,
		step: "05",
		title: "Test & Aftercare",
		text: "Pressure, flow, and heat are re-tested in front of you. You get maintenance guidance so the same fault is far less likely to return.",
		detail: "Follow-up check on request"
	}
];
function Process() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "process",
		className: "relative py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "How We Work"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-4 text-4xl sm:text-5xl",
						children: ["Five steps from first call to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-metal",
							children: "final test"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-muted-foreground",
						children: "Every BroBax visit follows the same sequence, so you always know what happens next, what it costs, and when it will be finished."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
				children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i % 3 * 90,
					from: i % 2 === 0 ? "left" : "right",
					className: "h-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "lux-card glow-ring sheen group flex h-full flex-col rounded-2xl p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-12 w-12 place-items-center rounded-xl border border-brass/30 bg-brass/10 text-brass",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, {
										className: "icon-pop h-5 w-5",
										"aria-hidden": "true"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-3xl text-brass/40 transition-colors duration-500 group-hover:text-brass/80",
									children: s.step
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-6 text-2xl",
								children: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 flex-1 text-sm leading-relaxed text-muted-foreground",
								children: s.text
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hairline my-5",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[0.68rem] tracking-[0.18em] uppercase text-brass-soft/80",
								children: s.detail
							})
						]
					})
				}, s.step))
			})]
		})
	});
}
var features = [
	{
		icon: CalendarCheck,
		title: "Priority Booking",
		text: "Reserve a preferred visit window and get a confirmation before we set out."
	},
	{
		icon: FileText,
		title: "Clear Written Quotes",
		text: "Scope and pricing explained in writing before any work starts — no surprises."
	},
	{
		icon: Gauge,
		title: "System Health Check",
		text: "Pressure, flow, and heating performance checked on every visit as standard."
	},
	{
		icon: BellRing,
		title: "Service Reminders",
		text: "Optional seasonal reminders so boiler and drainage care never slips."
	},
	{
		icon: Leaf,
		title: "Efficiency Advice",
		text: "Practical guidance to lower water and energy waste in your home."
	},
	{
		icon: ShieldCheck,
		title: "Aftercare Follow-Up",
		text: "A quick check-in after larger jobs to confirm everything runs as it should."
	},
	{
		icon: Wrench,
		title: "Planned Maintenance",
		text: "Recurring visits for landlords, rentals, and busy households."
	},
	{
		icon: Sparkles,
		title: "Upgrade Planning",
		text: "Fixture, bathroom, and heating upgrades scoped around your budget."
	}
];
var marquee = [
	"Emergency Callouts",
	"Boiler Servicing",
	"Leak Detection",
	"Bathroom Fit-Outs",
	"Drain Clearing",
	"Radiator Balancing",
	"Water Heaters",
	"Pipe Repairs",
	"Landlord Maintenance",
	"Upgrade Consultations"
];
function Advantages() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "advantages",
		className: "relative overflow-hidden py-24 lg:py-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "depth-bg pointer-events-none absolute inset-0 opacity-60",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "aurora pointer-events-none absolute -right-24 top-10 h-[26rem] w-[26rem] rounded-full bg-brass/10 blur-[130px]",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-5 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "mx-auto max-w-2xl text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "More From BroBex"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-4 text-4xl sm:text-5xl",
								children: [
									"Extra features that make service",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-metal-shimmer",
										children: "effortless"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-muted-foreground",
								children: "Beyond the repair itself, every booking includes the details that make the whole experience calm, clear, and easy to plan around."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4",
						children: features.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i % 4 * 80,
							from: i % 2 === 0 ? "left" : "right",
							className: "h-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "lux-card sheen lift group flex h-full flex-col rounded-2xl p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-11 w-11 place-items-center rounded-xl border border-brass/30 bg-brass/10 text-brass transition-transform duration-500 ease-[var(--ease-lux)] group-hover:-rotate-6 group-hover:scale-110",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, {
											className: "h-5 w-5",
											"aria-hidden": "true"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-5 text-xl",
										children: f.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2.5 flex-1 text-sm leading-relaxed text-muted-foreground",
										children: f.text
									})
								]
							})
						}, f.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						className: "mt-16",
						delay: 60,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "glass relative overflow-hidden rounded-2xl py-5",
							style: {
								maskImage: "linear-gradient(90deg, transparent, black 12%, black 88%, transparent)",
								WebkitMaskImage: "linear-gradient(90deg, transparent, black 12%, black 88%, transparent)"
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "marquee-track items-center gap-10 pr-10",
								"aria-hidden": "true",
								children: [...marquee, ...marquee].map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex shrink-0 items-center gap-3 text-xs tracking-[0.24em] uppercase text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1 w-1 rounded-full bg-brass" }), item]
								}, `${item}-${i}`))
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						className: "mt-12 text-center",
						delay: 120,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LuxRouteLink, {
							to: "/contact",
							children: "Explore your options"
						})
					})
				]
			})
		]
	});
}
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhyBrobax, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Process, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Advantages, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Emergency, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, { limit: 3 })
	] });
}
//#endregion
export { Index as component };
