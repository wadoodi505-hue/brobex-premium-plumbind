import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as MonitorSmartphone, a as Sparkles, b as Mail, f as Rocket, g as Palette, j as CodeXml, m as Phone, u as Search, v as MessageCircle } from "../_libs/lucide-react.mjs";
import { n as brobex_logo_default, t as SiteLayout } from "./SiteLayout-BFupRpb9.mjs";
import { t as PageHeader } from "./PageHeader-q3pUGuA6.mjs";
import { a as BRAND, s as LuxLink, u as Reveal } from "./router-DLSf9tlB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-brobex-Cbbzazwb.js
var import_jsx_runtime = require_jsx_runtime();
var skills = [
	{
		icon: CodeXml,
		title: "Custom Development",
		text: "Hand-built, fast, modern websites and web apps — no bloated templates, no drag-and-drop shortcuts."
	},
	{
		icon: Palette,
		title: "Premium UI Design",
		text: "Luxury-grade interfaces with real design systems: type scales, colour tokens, and motion that feels intentional."
	},
	{
		icon: MonitorSmartphone,
		title: "Fully Responsive",
		text: "Every layout is engineered for phones first, then scaled up to tablet and desktop without compromise."
	},
	{
		icon: Rocket,
		title: "Performance",
		text: "GPU-composited animation, optimised images, and lean code so pages feel instant on real devices."
	},
	{
		icon: Search,
		title: "SEO Foundations",
		text: "Semantic HTML, unique page metadata, structured data, and clean URLs built in from the start."
	},
	{
		icon: Sparkles,
		title: "Ongoing Support",
		text: "Content updates, new sections, and improvements handled quickly after launch — the site keeps evolving."
	}
];
var contacts = [
	{
		icon: Phone,
		label: "Call",
		value: BRAND.phoneDisplay,
		href: BRAND.phoneHref,
		external: false
	},
	{
		icon: MessageCircle,
		label: "WhatsApp",
		value: BRAND.whatsappDisplay,
		href: BRAND.whatsappHref,
		external: true
	},
	{
		icon: Mail,
		label: "Gmail",
		value: BRAND.email,
		href: `mailto:${BRAND.email}`,
		external: false
	}
];
function AboutBrobexPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Code. Design. Solve. Elevate.",
			title: "About",
			accent: "BroBex",
			intro: "BroBex is the web developer behind this website — building premium, fast, responsive sites for service brands that want to look and feel one level above their competition."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative pb-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-[0.8fr_1fr] lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					from: "left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lux-card glow-ring sheen group mx-auto grid max-w-xs place-items-center rounded-[1.75rem] p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "float-slow grid h-40 w-40 place-items-center overflow-hidden rounded-full border border-brass/40 bg-surface-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: brobex_logo_default,
									alt: "BroBex web developer logo",
									width: 320,
									height: 320,
									loading: "lazy",
									decoding: "async",
									className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-6 text-center font-display text-3xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-metal-shimmer",
									children: "Bro"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: "Bex"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow mt-2 text-center",
								children: "Web Developer"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					from: "right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-3xl sm:text-4xl",
							children: [
								"Websites that ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-metal",
									children: "earn trust"
								}),
								" in the first five seconds"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 space-y-4 text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Most small-business websites lose customers before a word is read — slow loading, dated layouts, and no clear way to get in touch. BroBex fixes that: clear structure, confident design, and a call-to-action that is never more than a tap away." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This BroBax plumbing site is an example of that approach — a dark luxury design system, smooth GPU-accelerated motion, dedicated pages for every service, fixed call and WhatsApp buttons, and SEO metadata on every page." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Need something similar for your own business — a portfolio, a store, a booking site, or a full brand refresh? Message BroBex directly using the details below." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LuxLink, {
								href: BRAND.whatsappHref,
								target: "_blank",
								rel: "noopener noreferrer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
									className: "h-4 w-4",
									"aria-hidden": "true"
								}), "Message on WhatsApp"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LuxLink, {
								href: `mailto:${BRAND.email}`,
								variant: "outline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "h-4 w-4",
									"aria-hidden": "true"
								}), "Email BroBex"]
							})]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative py-20 lg:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "What BroBex Does"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-4 text-4xl sm:text-5xl",
						children: ["Design, build, and ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-metal",
							children: "elevate"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
					children: skills.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i % 3 * 90,
						from: i % 2 === 0 ? "left" : "right",
						className: "h-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "lux-card glow-ring sheen group flex h-full flex-col rounded-2xl p-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-12 w-12 place-items-center rounded-xl border border-brass/30 bg-brass/10 text-brass",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, {
										className: "icon-pop h-5 w-5",
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-6 text-2xl",
									children: s.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 flex-1 text-sm leading-relaxed text-muted-foreground",
									children: s.text
								})
							]
						})
					}, s.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "contact-brobex",
			className: "relative pb-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Contact BroBex"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-4 text-4xl sm:text-5xl",
								children: ["Same number, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-metal",
									children: "same fast reply"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-muted-foreground",
								children: "Calls, WhatsApp messages, and emails all reach BroBex directly."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-5 sm:grid-cols-3",
						children: contacts.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i * 90,
							from: "scale",
							className: "h-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: c.href,
								...c.external ? {
									target: "_blank",
									rel: "noopener noreferrer"
								} : {},
								className: "lux-card glow-ring sheen group press flex h-full flex-col rounded-2xl p-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-12 w-12 place-items-center rounded-xl border border-brass/30 bg-brass/10 text-brass",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, {
											className: "icon-pop h-5 w-5",
											"aria-hidden": "true"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "eyebrow mt-6",
										children: c.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-2xl break-all text-brass-soft",
										children: c.value
									})
								]
							})
						}, c.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						className: "mt-12",
						delay: 120,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass glow-ring rounded-2xl p-7 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Credit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 font-display text-2xl sm:text-3xl",
									children: [
										"This site is designed & developed by",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-metal-shimmer",
											children: "BroBex"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-sm text-muted-foreground",
									children: [
										"Want one for your business? Tap the logo in the header any time to come back here, or",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/contact",
											className: "text-brass-soft sweep-underline hover:text-brass",
											children: "send a message"
										}),
										"."
									]
								})
							]
						})
					})
				]
			})
		})
	] });
}
//#endregion
export { AboutBrobexPage as component };
