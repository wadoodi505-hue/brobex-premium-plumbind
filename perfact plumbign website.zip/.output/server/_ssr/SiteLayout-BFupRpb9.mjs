import { n as __toESM } from "../_runtime.mjs";
import { c as require_react, s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Instagram, O as Facebook, b as Mail, m as Phone, t as X, v as MessageCircle, x as Linkedin, y as Menu } from "../_libs/lucide-react.mjs";
import { a as BRAND, d as SERVICES, l as NAV_LINKS, s as LuxLink } from "./router-DLSf9tlB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SiteLayout-BFupRpb9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var brobex_logo_default = "/assets/brobex-logo-DuB_-XK_.png";
function Logo({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `inline-flex items-center gap-2.5 ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative grid h-10 w-10 shrink-0 place-items-center rounded-full border border-brass/40 bg-surface-2 overflow-hidden will-change-transform transition-transform duration-500 ease-[var(--ease-lux)] hover:scale-105",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: brobex_logo_default,
				alt: "BroBex logo",
				width: 80,
				height: 80,
				loading: "eager",
				decoding: "async",
				className: "h-full w-full object-cover"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-display text-2xl leading-none tracking-tight",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-metal",
				children: "Bro"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-foreground",
				children: "Bex"
			})]
		})]
	});
}
var underline = "relative text-sm transition-colors duration-300 after:absolute after:-bottom-1.5 after:left-0 after:h-px after:bg-brass after:transition-all after:duration-300";
function Nav() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? "glass border-b py-2" : "border-b border-transparent py-4"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl items-center justify-between gap-6 px-5 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "min-w-0",
					"aria-label": "BroBax home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Main",
					className: "hidden items-center gap-7 xl:flex",
					children: NAV_LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						activeOptions: { exact: link.to === "/" },
						className: `${underline} text-foreground/75 after:w-0 hover:text-brass hover:after:w-full`,
						activeProps: { className: "text-brass after:w-full" },
						children: link.label
					}, link.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: BRAND.phoneHref,
							className: "hidden items-center gap-2 text-sm text-brass-soft transition-colors hover:text-brass lg:inline-flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "h-4 w-4",
								"aria-hidden": "true"
							}), BRAND.phoneDisplay]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LuxLink, {
								href: "/contact",
								className: "whitespace-nowrap",
								children: "Request Service"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOpen((v) => !v),
							"aria-expanded": open,
							"aria-label": open ? "Close menu" : "Open menu",
							className: "grid h-11 w-11 shrink-0 place-items-center rounded-full border border-border text-foreground transition-colors hover:border-brass/50 hover:text-brass xl:hidden",
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `glass fixed inset-x-0 top-[4.5rem] mx-3 origin-top rounded-2xl p-6 transition-[transform,opacity] duration-500 ease-[var(--ease-lux)] will-change-transform xl:hidden ${open ? "pointer-events-auto translate-x-0 opacity-100" : "pointer-events-none translate-x-[calc(100%+1.5rem)] opacity-0"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Mobile",
				className: `flex flex-col divide-y divide-border ${open ? "stagger-slide" : ""}`,
				children: NAV_LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: link.to,
					activeOptions: { exact: link.to === "/" },
					onClick: () => setOpen(false),
					className: "py-3.5 font-display text-2xl text-foreground/90 transition-colors hover:text-brass",
					activeProps: { className: "text-brass underline decoration-brass decoration-1 underline-offset-8" },
					children: link.label
				}, link.to))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LuxLink, {
					href: "/contact",
					onClick: () => setOpen(false),
					children: "Request a Service"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LuxLink, {
					href: BRAND.phoneHref,
					variant: "outline",
					children: ["Call ", BRAND.phoneDisplay]
				})]
			})]
		})]
	});
}
var socials = [
	{
		label: "Facebook",
		icon: Facebook
	},
	{
		label: "Instagram",
		icon: Instagram
	},
	{
		label: "LinkedIn",
		icon: Linkedin
	}
];
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "relative border-t border-border bg-surface/40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 py-16 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-12 lg:grid-cols-[1.3fr_1fr_1fr_1.1fr]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-xs text-sm leading-relaxed text-muted-foreground",
								children: "BroBax delivers premium plumbing and heating services built on precision, reliability, and transparent communication."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 flex gap-3",
								children: socials.map((social) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									"aria-label": `${social.label} (placeholder)`,
									className: "group press grid h-10 w-10 place-items-center rounded-full border border-border text-muted-foreground transition-all duration-300 hover:-translate-y-0.5 hover:border-brass/50 hover:text-brass",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(social.icon, {
										className: "icon-pop h-4 w-4",
										"aria-hidden": "true"
									})
								}, social.label))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							"aria-label": "Footer navigation",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "eyebrow",
								children: "Navigation"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-5 space-y-3",
								children: NAV_LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: link.to,
									className: "link-nudge text-sm text-muted-foreground hover:text-brass",
									children: link.label
								}) }, link.to))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "eyebrow",
							children: "Services"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-5 space-y-3",
							children: SERVICES.slice(0, 6).map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/services/$slug",
								params: { slug: service.slug },
								className: "link-nudge text-sm text-muted-foreground hover:text-brass",
								children: service.title
							}) }, service.slug))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "eyebrow",
							children: "Contact"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-5 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: BRAND.phoneHref,
									className: "link-nudge text-sm text-muted-foreground hover:text-brass",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
										className: "h-4 w-4 shrink-0",
										"aria-hidden": "true"
									}), BRAND.phoneDisplay]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: BRAND.whatsappHref,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "link-nudge text-sm text-muted-foreground hover:text-brass",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
											className: "h-4 w-4 shrink-0",
											"aria-hidden": "true"
										}),
										"WhatsApp ",
										BRAND.whatsappDisplay
									]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `mailto:${BRAND.email}`,
									className: "link-nudge text-sm break-all text-muted-foreground hover:text-brass",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
										className: "h-4 w-4 shrink-0",
										"aria-hidden": "true"
									}), BRAND.email]
								}) })
							]
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hairline mt-14",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-2 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" BroBax. All rights reserved."
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Premium Plumbing & Heating Services" })]
				})
			]
		})
	});
}
function FloatingContact() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: BRAND.phoneHref,
		"aria-label": `Call BroBax on ${BRAND.phoneDisplay}`,
		className: "glass group press pulse-ring fixed bottom-5 left-4 z-50 grid h-14 w-14 place-items-center rounded-full border border-brass/40 text-brass shadow-[var(--shadow-glow)] transition-transform duration-500 hover:-translate-y-1 hover:border-brass sm:bottom-7 sm:left-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
			className: "h-5 w-5",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pointer-events-none absolute left-16 hidden rounded-full border border-border bg-surface/90 px-3 py-1.5 text-[0.68rem] tracking-[0.18em] whitespace-nowrap uppercase text-foreground/85 opacity-0 transition-opacity duration-300 group-hover:opacity-100 lg:block",
			children: "Call Now"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: BRAND.whatsappHref,
		target: "_blank",
		rel: "noopener noreferrer",
		"aria-label": `Message BroBax on WhatsApp at ${BRAND.whatsappDisplay}`,
		className: "glass group press pulse-ring fixed bottom-5 right-4 z-50 grid h-14 w-14 place-items-center rounded-full border border-brass/40 text-brass shadow-[var(--shadow-glow)] transition-transform duration-500 hover:-translate-y-1 hover:border-brass sm:bottom-7 sm:right-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
			className: "h-5 w-5",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pointer-events-none absolute right-16 hidden rounded-full border border-border bg-surface/90 px-3 py-1.5 text-[0.68rem] tracking-[0.18em] whitespace-nowrap uppercase text-foreground/85 opacity-0 transition-opacity duration-300 group-hover:opacity-100 lg:block",
			children: "WhatsApp"
		})]
	})] });
}
function SiteLayout({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingContact, {})
		]
	});
}
//#endregion
export { brobex_logo_default as n, SiteLayout as t };
