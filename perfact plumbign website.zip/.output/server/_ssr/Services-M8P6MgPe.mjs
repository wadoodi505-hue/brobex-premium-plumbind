import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { V as ArrowRight } from "../_libs/lucide-react.mjs";
import { d as SERVICES, u as Reveal } from "./router-DLSf9tlB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Services-M8P6MgPe.js
var import_jsx_runtime = require_jsx_runtime();
function Services({ heading = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "services",
		className: "relative py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: [heading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Our Services"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-4 text-4xl sm:text-5xl",
						children: ["A complete plumbing & heating ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-metal",
							children: "service portfolio"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-muted-foreground",
						children: "From urgent repairs to planned maintenance, every visit follows the same standard of workmanship and clear communication."
					})
				]
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:gap-6 ${heading ? "mt-14" : ""}`,
				children: SERVICES.map((service, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i % 3 * 90,
					from: i % 2 === 0 ? "left" : "right",
					className: "h-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "lux-card glow-ring sheen group flex h-full flex-col rounded-2xl p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-12 w-12 place-items-center rounded-xl border border-brass/30 bg-brass/10 text-brass transition-transform duration-500 group-hover:scale-105",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(service.icon, {
									className: "icon-pop h-5 w-5",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-6 text-2xl",
								children: service.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted-foreground",
								children: service.text
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 flex-1 space-y-2",
								children: service.includes.slice(0, 3).map((inc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-2 text-xs leading-relaxed text-muted-foreground/85",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1.5 h-1 w-1 shrink-0 rounded-full bg-brass",
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: inc })]
								}, inc))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-[0.66rem] tracking-[0.18em] uppercase text-brass-soft/80",
								children: service.response
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hairline my-6",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/services/$slug",
								params: { slug: service.slug },
								className: "link-nudge text-[0.72rem] font-semibold tracking-[0.2em] uppercase text-brass-soft hover:text-brass",
								children: ["View Details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									className: "h-3.5 w-3.5 transition-transform duration-500 group-hover:translate-x-1",
									"aria-hidden": "true"
								})]
							})
						]
					})
				}, service.slug))
			})]
		})
	});
}
//#endregion
export { Services as t };
