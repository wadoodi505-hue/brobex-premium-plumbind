import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { m as Phone } from "../_libs/lucide-react.mjs";
import { a as BRAND, c as LuxRouteLink, s as LuxLink, u as Reveal } from "./router-DLSf9tlB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Emergency--jNbWuPk.js
var import_jsx_runtime = require_jsx_runtime();
var emergency_bg_default = "/assets/emergency-bg-DP6IQDe5.jpg";
function Emergency() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden py-20 lg:py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: emergency_bg_default,
				alt: "",
				"aria-hidden": "true",
				width: 1600,
				height: 900,
				loading: "lazy",
				className: "ken-burns absolute inset-0 h-full w-full object-cover opacity-60"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 bg-[radial-gradient(80%_80%_at_50%_50%,oklch(0.16_0.008_60/60%),oklch(0.16_0.008_60/95%))]",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto max-w-4xl px-5 text-center lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Emergency Plumbing"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-4 text-4xl leading-tight sm:text-5xl lg:text-6xl",
						children: ["Plumbing Problem? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-metal",
							children: "Let’s Get It Handled."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-5 max-w-2xl text-muted-foreground",
						children: "Contact BroBax for professional plumbing assistance and dependable service."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LuxLink, {
							href: BRAND.phoneHref,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "h-4 w-4",
									"aria-hidden": "true"
								}),
								"Call ",
								BRAND.phoneDisplay
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LuxRouteLink, {
							to: "/contact",
							variant: "outline",
							children: "Request a Service"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-12 grid gap-4 sm:grid-cols-3",
						children: [
							{
								k: "First priority",
								v: "Isolate the supply and stop further damage to your home."
							},
							{
								k: "Then",
								v: "Diagnose the true cause and confirm the cost before any work."
							},
							{
								k: "Before we leave",
								v: "Re-test, clean down, and explain how to avoid a repeat."
							}
						].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass glow-ring rounded-2xl p-5 text-left transition-transform duration-500 hover:-translate-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "eyebrow",
								children: d.k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-2 text-sm leading-relaxed text-foreground/85",
								children: d.v
							})]
						}, d.k))
					})
				] })
			})
		]
	});
}
//#endregion
export { Emergency as t };
