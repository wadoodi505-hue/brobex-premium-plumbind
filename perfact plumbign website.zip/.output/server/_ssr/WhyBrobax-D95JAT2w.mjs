import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { B as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { c as LuxRouteLink, u as Reveal } from "./router-DLSf9tlB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/WhyBrobax-D95JAT2w.js
var import_jsx_runtime = require_jsx_runtime();
var why_brobax_default = "/assets/why-brobax-CD3cl9Fo.jpg";
var points = [
	{
		title: "Precision",
		text: "Diagnosis before action. We identify the real cause, then repair it properly rather than patching a symptom.",
		detail: "Pressure and flow re-tested before we sign off the job."
	},
	{
		title: "Reliability",
		text: "Confirmed appointments, clear arrival windows, and solutions chosen to hold up over the long term.",
		detail: "Quality parts, protected floors, and a clean finish every visit."
	},
	{
		title: "Transparency",
		text: "You hear what the work involves and what it costs before anything starts — no assumptions, no surprises.",
		detail: "Price agreed up front — no call-out surprises added later."
	}
];
function WhyBrobax() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "why",
		className: "relative py-24 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-2 lg:gap-20 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute -inset-4 rounded-[2rem] bg-brass/5 blur-2xl",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-[1.75rem] border border-border shadow-[var(--shadow-lux)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: why_brobax_default,
						alt: "BroBax plumbing technician adjusting brass valves on copper pipework",
						width: 1200,
						height: 1408,
						loading: "lazy",
						className: "ken-burns h-[26rem] w-full object-cover lg:h-[36rem]"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 bg-[linear-gradient(to_top,oklch(0.16_0.008_60/70%),transparent_60%)]",
						"aria-hidden": "true"
					})]
				})]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Why BroBax"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-4 text-4xl sm:text-5xl",
						children: ["Precision. Reliability. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-metal",
							children: "Transparency."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-muted-foreground",
						children: "Plumbing work is only as good as the care behind it. BroBax treats every call as a service experience — considered, communicative, and finished to a standard you notice."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 space-y-8",
					children: points.map((point, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 120,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group grid grid-cols-[auto_minmax(0,1fr)] gap-5 rounded-2xl p-3 transition-colors duration-500 hover:bg-brass/5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-display text-2xl text-brass/60 transition-all duration-500 group-hover:-translate-y-0.5 group-hover:text-brass",
								children: ["0", i + 1]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "sweep-underline inline-block text-2xl",
										children: point.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: point.text
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs leading-relaxed text-brass-soft/75",
										children: point.detail
									})
								]
							})]
						})
					}, point.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "mt-10",
					delay: 120,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LuxRouteLink, {
						to: "/contact",
						children: ["Contact Us", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4 transition-transform duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" })]
					})
				})
			] })]
		})
	});
}
//#endregion
export { WhyBrobax as t };
