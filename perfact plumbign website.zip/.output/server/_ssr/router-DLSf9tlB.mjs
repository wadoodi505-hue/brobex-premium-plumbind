import { n as __toESM } from "../_runtime.mjs";
import { a as Trigger2, c as require_react, i as Root2, n as Header, r as Item, s as require_jsx_runtime, t as Content2 } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { M as notFound, _ as createLink, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Droplets, E as Flame, P as ChevronDown, R as Bath, T as Gauge, i as Utensils, n as Wrench, o as Siren, r as Waves, s as ShowerHead, u as Search } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as __exportAll } from "./server-FLeGY12Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/serviceData-_jNHhle1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BRAND = {
	name: "BroBax",
	email: "BroBex.ffx@gmail.com",
	phoneDisplay: "0370-999-5042",
	phoneHref: "tel:+9203709995042",
	whatsappDisplay: "+92 370-999-5042",
	whatsappHref: "https://wa.me/923709995042"
};
var NAV_LINKS = [
	{
		label: "Home",
		to: "/"
	},
	{
		label: "Services",
		to: "/services"
	},
	{
		label: "About",
		to: "/about"
	},
	{
		label: "Why BroBax",
		to: "/why-brobax"
	},
	{
		label: "Reviews",
		to: "/reviews"
	},
	{
		label: "FAQ",
		to: "/faq"
	},
	{
		label: "Contact",
		to: "/contact"
	}
];
function Reveal({ children, as: Tag = "div", delay = 0, from = "bottom", className = "" }) {
	const ref = (0, import_react.useRef)(null);
	const [visible, setVisible] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		if (!("IntersectionObserver" in window)) {
			setVisible(true);
			return;
		}
		const observer = new IntersectionObserver((entries) => {
			if (entries[0]?.isIntersecting) {
				setVisible(true);
				observer.disconnect();
			}
		}, {
			threshold: 0,
			rootMargin: "200px 0px 200px 0px"
		});
		observer.observe(node);
		const fallback = window.setTimeout(() => {
			setVisible(true);
			observer.disconnect();
		}, 1200);
		return () => {
			observer.disconnect();
			window.clearTimeout(fallback);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		ref,
		"data-visible": visible ? "true" : "false",
		"data-from": from,
		style: { transitionDelay: `${delay}ms` },
		className: `reveal ${className}`,
		children
	});
}
var base = "group relative inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-[0.78rem] font-semibold uppercase tracking-[0.18em] transition-all duration-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background";
var variants = {
	primary: "bg-[image:var(--gradient-brass)] text-primary-foreground shadow-[var(--shadow-glow)] hover:brightness-110 hover:-translate-y-0.5 active:translate-y-0",
	outline: "border border-brass/45 text-brass-soft hover:border-brass hover:bg-brass/10 hover:-translate-y-0.5",
	ghost: "text-foreground/80 hover:text-brass"
};
function LuxLink({ variant = "primary", className = "", children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: `${base} ${variants[variant]} ${className}`,
		...props,
		children
	});
}
function LuxButton({ variant = "primary", className = "", children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: `${base} ${variants[variant]} ${className}`,
		...props,
		children
	});
}
var LuxAnchor = (0, import_react.forwardRef)(({ variant = "primary", className = "", children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
	ref,
	className: `${base} ${variants[variant]} ${className}`,
	...props,
	children
}));
LuxAnchor.displayName = "LuxAnchor";
var LuxRouteLink = createLink(LuxAnchor);
var SERVICES = [
	{
		slug: "emergency-plumbing",
		icon: Siren,
		title: "Emergency Plumbing",
		text: "Urgent leaks, blockages, and failures handled calmly and quickly.",
		intro: "When water is where it should not be, the priority is control first and repair second. BroBax stabilises the situation, protects your home, then explains the fix before any work begins.",
		includes: [
			"Immediate isolation of the water or heating supply",
			"Burst and split pipe containment and repair",
			"Severe blockage and overflow clearance",
			"Failed valve, cistern, and connection replacement",
			"Damage-limiting clean-down before we leave"
		],
		signs: [
			"Water running or spraying that you cannot stop",
			"A sudden drop or loss of pressure",
			"Sewage smell or waste backing up",
			"No heating or hot water in cold conditions"
		],
		response: "Priority same-day attendance whenever the situation is unsafe or actively causing damage."
	},
	{
		slug: "drain-cleaning",
		icon: Waves,
		title: "Drain Cleaning",
		text: "Slow or blocked drains cleared thoroughly, not just temporarily.",
		intro: "Most drains block again because only the surface obstruction was removed. We clear the full run and check flow properly so the problem does not quietly return.",
		includes: [
			"Mechanical clearance of sinks, baths, and showers",
			"Soil stack and external gully clearing",
			"Grease, scale, and debris build-up removal",
			"Flow testing after clearance",
			"Advice on preventing repeat blockages"
		],
		signs: [
			"Water draining slowly or standing in the basin",
			"Gurgling sounds after the tap is turned off",
			"Recurring smells around plugholes",
			"More than one fixture draining poorly"
		],
		response: "Usually booked within a day or two, sooner if waste water is backing up."
	},
	{
		slug: "leak-detection-repair",
		icon: Search,
		title: "Leak Detection & Repair",
		text: "Careful diagnosis that finds the source with minimal disruption.",
		intro: "A visible damp patch is rarely where the leak starts. We trace it methodically, opening as little of your home as possible, then repair the actual cause.",
		includes: [
			"Systematic tracing of concealed and under-floor leaks",
			"Pressure and isolation testing",
			"Targeted access with minimal disturbance",
			"Permanent joint, pipe, or fitting repair",
			"Re-test and confirmation before sign-off"
		],
		signs: [
			"Unexplained damp, staining, or bubbling paint",
			"A meter that moves with everything turned off",
			"Musty smell in one room only",
			"Warm or cold patches on a floor"
		],
		response: "Booked promptly, with urgent priority where the leak is worsening."
	},
	{
		slug: "water-heater-services",
		icon: Droplets,
		title: "Water Heater Services",
		text: "Repair, servicing, and replacement for consistent hot water.",
		intro: "Hot water should be predictable. We service, repair, or replace heaters and cylinders with the correct sizing so temperature and recovery stay steady.",
		includes: [
			"Fault diagnosis on electric and gas units",
			"Thermostat, element, and valve replacement",
			"Descaling and full service",
			"Correctly sized replacement and installation",
			"Safety and pressure checks"
		],
		signs: [
			"Hot water running out quickly",
			"Fluctuating or lukewarm temperature",
			"Rumbling, knocking, or hissing from the unit",
			"Moisture or rust around the base"
		],
		response: "Repairs typically same or next day; replacements scheduled to suit you."
	},
	{
		slug: "boiler-heating-services",
		icon: Flame,
		title: "Boiler & Heating Services",
		text: "Heating systems tuned for steady, efficient warmth.",
		intro: "Heating faults are usually a system issue rather than a single part. We look at the whole circuit — pressure, circulation, and controls — so the fix holds.",
		includes: [
			"Boiler fault finding and repair",
			"System pressure and circulation correction",
			"Radiator balancing and bleeding",
			"Pump, valve, and control replacement",
			"Planned annual servicing"
		],
		signs: [
			"Radiators cold at the top or the bottom",
			"Boiler locking out or losing pressure",
			"Noisy pipework or banging on start-up",
			"Rooms heating unevenly"
		],
		response: "Heating loss in cold weather is treated as priority work."
	},
	{
		slug: "pipe-repair-replacement",
		icon: Wrench,
		title: "Pipe Repair & Replacement",
		text: "Clean, durable pipework repairs finished to a high standard.",
		intro: "Pipework is the part of the job nobody sees, which is exactly why we finish it properly — correctly supported, cleanly routed, and pressure tested.",
		includes: [
			"Split, corroded, and failed section replacement",
			"Copper, plastic, and mixed-material jointing",
			"Re-routing around renovations",
			"Insulation against freezing",
			"Full pressure testing after work"
		],
		signs: [
			"Repeated leaks in the same run",
			"Discoloured water or visible corrosion",
			"Persistent low pressure",
			"Pipework that rattles or moves in use"
		],
		response: "Scheduled work with a clear plan, timeline, and cost agreed up front."
	},
	{
		slug: "bathroom-plumbing",
		icon: Bath,
		title: "Bathroom Plumbing",
		text: "Refined installation and repair work for bathrooms of any scale.",
		intro: "Bathrooms show every shortcut. Levels, seals, and finish matter as much as the plumbing behind them, so we treat both with the same care.",
		includes: [
			"Basin, bath, shower, and WC installation",
			"Supply and waste pipework alterations",
			"Shower valve and pressure improvement",
			"Silicone sealing and finishing",
			"Leak and drainage testing"
		],
		signs: [
			"Weak or fluctuating shower pressure",
			"Water escaping around trays or seals",
			"Fixtures loose or sitting unevenly",
			"A refit or upgrade being planned"
		],
		response: "Repairs booked quickly; installations planned around your schedule."
	},
	{
		slug: "kitchen-plumbing",
		icon: Utensils,
		title: "Kitchen Plumbing",
		text: "Sinks, supply lines, and appliance connections done precisely.",
		intro: "Kitchen plumbing sits behind cabinetry, so access and neatness are part of the job. We install and repair in a way that stays serviceable later.",
		includes: [
			"Sink, tap, and waste installation",
			"Dishwasher and washing machine connection",
			"Under-sink leak repair",
			"Waste re-routing for new units",
			"Water filter and boiling tap fitting"
		],
		signs: [
			"Damp or swollen cabinet bases",
			"Slow draining sink or trapped odours",
			"Dripping or stiff taps",
			"A new appliance needing connection"
		],
		response: "Straightforward jobs often completed in a single visit."
	},
	{
		slug: "fixture-installation",
		icon: ShowerHead,
		title: "Fixture Installation",
		text: "Taps, showers, and fittings installed level, sealed, and tested.",
		intro: "Good fittings deserve a good installation. Everything is set level, sealed correctly, and tested under real use before we call it finished.",
		includes: [
			"Tap, mixer, and shower installation",
			"Radiator and towel rail fitting",
			"WC and cistern replacement",
			"Isolation valve additions for easier servicing",
			"Post-installation testing and adjustment"
		],
		signs: [
			"New fittings waiting to be installed",
			"Existing fixtures dripping or seized",
			"Poor flow from a recently fitted tap",
			"Visible sealant failure or movement"
		],
		response: "Booked at a convenient time, usually completed within one visit."
	},
	{
		slug: "preventive-maintenance",
		icon: Gauge,
		title: "Preventive Maintenance",
		text: "Planned checks that catch small issues before they escalate.",
		intro: "The cheapest plumbing repair is the one you never needed. A planned check finds the early signs while they are still minor.",
		includes: [
			"Full visual inspection of visible pipework",
			"Pressure, flow, and drainage checks",
			"Heating and hot water performance review",
			"Seal, valve, and connection assessment",
			"Written summary of findings and priorities"
		],
		signs: [
			"An older system with no recent service history",
			"A property being let or sold",
			"Small recurring drips or noises",
			"Wanting to avoid winter surprises"
		],
		response: "Scheduled at your convenience, typically annually."
	}
];
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-DLSf9tlB.js
var styles_default = "/assets/styles-BsIbgmcy.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$9 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "BroBax — Premium Plumbing & Heating Services" },
			{
				name: "description",
				content: "Premium plumbing and heating services from BroBax, delivered with precision, reliability, and exceptional service."
			},
			{
				name: "author",
				content: "BroBax"
			},
			{
				property: "og:site_name",
				content: "BroBax"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&family=Manrope:wght@400;500;600;700&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.png",
				type: "image/png"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$9.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})]
	});
}
var $$splitComponentImporter$8 = () => import("./routes-Bp9SwlT8.mjs");
var title$7 = "BroBax — Premium Plumbing & Heating Services";
var description$7 = "BroBax delivers premium plumbing and heating services with precision, reliability, and transparent communication. Request a service or call 0370-999-5042.";
var Route$8 = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: title$7 },
			{
				name: "description",
				content: description$7
			},
			{
				property: "og:title",
				content: title$7
			},
			{
				property: "og:description",
				content: description$7
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "Plumber",
				name: BRAND.name,
				description: description$7,
				email: BRAND.email,
				telephone: BRAND.phoneDisplay
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./about-Buutunh9.mjs");
var title$6 = "About BroBax | Premium Plumbing & Heating";
var description$6 = "BroBax is a premium plumbing and heating service built on precise workmanship, dependable scheduling, and clear communication on every visit.";
var Route$7 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: title$6 },
		{
			name: "description",
			content: description$6
		},
		{
			property: "og:title",
			content: title$6
		},
		{
			property: "og:description",
			content: description$6
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./about-brobex-Cbbzazwb.mjs");
var title$5 = "About BroBex — Web Developer | Code. Design. Solve. Elevate.";
var description$5 = "BroBex is the web developer behind this site. Custom websites, premium UI design, SEO and performance work. Contact BroBex on 0370-999-5042, WhatsApp, or BroBex.ffx@gmail.com.";
var Route$6 = createFileRoute("/about-brobex")({
	head: () => ({
		meta: [
			{ title: title$5 },
			{
				name: "description",
				content: description$5
			},
			{
				property: "og:title",
				content: title$5
			},
			{
				property: "og:description",
				content: description$5
			},
			{
				property: "og:type",
				content: "profile"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "ProfessionalService",
				name: "BroBex — Web Developer",
				description: description$5,
				email: BRAND.email,
				telephone: BRAND.phoneDisplay,
				slogan: "Code. Design. Solve. Elevate."
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./contact-j1bQG9BX.mjs");
var title$4 = "Contact BroBax | Request a Plumbing Service";
var description$4 = "Request a BroBax plumbing or heating visit. Call 0370-999-5042, message on WhatsApp, email BroBex.ffx@gmail.com, or send the service request form.";
var Route$5 = createFileRoute("/contact")({
	head: () => ({
		meta: [
			{ title: title$4 },
			{
				name: "description",
				content: description$4
			},
			{
				property: "og:title",
				content: title$4
			},
			{
				property: "og:description",
				content: description$4
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "Plumber",
				name: BRAND.name,
				email: BRAND.email,
				telephone: BRAND.phoneDisplay,
				contactPoint: {
					"@type": "ContactPoint",
					contactType: "customer service",
					telephone: BRAND.phoneDisplay,
					email: BRAND.email
				}
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
var FAQS = [
	{
		q: "What plumbing services does BroBax provide?",
		a: "BroBax covers emergency plumbing, drain cleaning, leak detection and repair, water heater and boiler work, pipe repair and replacement, bathroom and kitchen plumbing, fixture installation, and preventive maintenance."
	},
	{
		q: "How quickly can you respond to an urgent issue?",
		a: "Urgent calls are prioritised. Get in touch by phone and we will confirm the soonest available visit along with a clear arrival window."
	},
	{
		q: "Will I know the cost before work begins?",
		a: "Yes. We explain the issue, the recommended fix, and the cost before starting so you can make a decision with full information."
	},
	{
		q: "Do you handle both plumbing and heating?",
		a: "We do. Plumbing and heating systems are closely connected, so we service both — including boilers, water heaters, and associated pipework."
	},
	{
		q: "How do I book a service with BroBax?",
		a: `Call ${BRAND.phoneDisplay}, email ${BRAND.email}, or send the request form on this page and we will follow up to arrange a visit.`
	}
];
function Faq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "faq",
		className: "relative py-24 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "FAQ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 text-4xl sm:text-5xl",
					children: ["Questions, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-metal",
						children: "answered clearly"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-muted-foreground",
					children: "Still unsure about something? A short conversation is usually the fastest way to get a straight answer."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LuxLink, {
					href: BRAND.phoneHref,
					variant: "outline",
					className: "mt-8",
					children: "Call BroBax"
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 100,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
					type: "single",
					collapsible: true,
					className: "w-full",
					children: FAQS.map((faq) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
						value: faq.q,
						className: "border-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
							className: "py-6 text-left font-display text-xl hover:text-brass hover:no-underline",
							children: faq.q
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
							className: "pb-6 text-sm leading-relaxed text-muted-foreground",
							children: faq.a
						})]
					}, faq.q))
				})
			})]
		})
	});
}
var $$splitComponentImporter$4 = () => import("./faq-BSAVczd8.mjs");
var title$3 = "FAQ | BroBax Plumbing & Heating";
var description$3 = "Answers to common questions about BroBax services, response times, pricing transparency, heating work, and how to book a plumbing visit.";
var Route$4 = createFileRoute("/faq")({
	head: () => ({
		meta: [
			{ title: title$3 },
			{
				name: "description",
				content: description$3
			},
			{
				property: "og:title",
				content: title$3
			},
			{
				property: "og:description",
				content: description$3
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "FAQPage",
				mainEntity: FAQS.map((faq) => ({
					"@type": "Question",
					name: faq.q,
					acceptedAnswer: {
						"@type": "Answer",
						text: faq.a
					}
				}))
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./reviews-lA0Ax2N-.mjs");
var title$2 = "Reviews | BroBax Plumbing & Heating";
var description$2 = "Sample review content showing the BroBax service standard across emergency plumbing, leak detection, heating, bathrooms, kitchens, and maintenance visits.";
var Route$3 = createFileRoute("/reviews")({
	head: () => ({ meta: [
		{ title: title$2 },
		{
			name: "description",
			content: description$2
		},
		{
			property: "og:title",
			content: title$2
		},
		{
			property: "og:description",
			content: description$2
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./why-brobax-D8_RZp2x.mjs");
var title$1 = "Why BroBax | Precision, Reliability, Transparency";
var description$1 = "Why clients choose BroBax: precise diagnosis before action, reliable scheduling and long-lasting solutions, and transparent pricing explained before work starts.";
var Route$2 = createFileRoute("/why-brobax")({
	head: () => ({ meta: [
		{ title: title$1 },
		{
			name: "description",
			content: description$1
		},
		{
			property: "og:title",
			content: title$1
		},
		{
			property: "og:description",
			content: description$1
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./services.index-scRqm3zT.mjs");
var title = "Plumbing & Heating Services | BroBax";
var description = "Explore BroBax plumbing and heating services: emergency plumbing, drain cleaning, leak detection, water heaters, boilers, pipework, bathrooms, kitchens, and maintenance.";
var Route$1 = createFileRoute("/services/")({
	head: () => ({ meta: [
		{ title },
		{
			name: "description",
			content: description
		},
		{
			property: "og:title",
			content: title
		},
		{
			property: "og:description",
			content: description
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
function getService(slug) {
	return SERVICES.find((service) => service.slug === slug);
}
var $$splitComponentImporter = () => import("./services._slug-XjtSGdIN.mjs");
var Route = createFileRoute("/services/$slug")({
	loader: ({ params }) => {
		const service = getService(params.slug);
		if (!service) throw notFound();
		return { slug: service.slug };
	},
	head: ({ params }) => {
		const service = getService(params.slug);
		const title = service ? `${service.title} | BroBax` : "Service | BroBax";
		const description = service ? `${service.text} ${service.intro}`.slice(0, 155) : "Premium plumbing and heating services from BroBax.";
		return { meta: [
			{ title },
			{
				name: "description",
				content: description
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: description
			},
			{
				property: "og:type",
				content: "article"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$9
});
var AboutRoute = Route$7.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$9
});
var AboutBrobexRoute = Route$6.update({
	id: "/about-brobex",
	path: "/about-brobex",
	getParentRoute: () => Route$9
});
var ContactRoute = Route$5.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$9
});
var FaqRoute = Route$4.update({
	id: "/faq",
	path: "/faq",
	getParentRoute: () => Route$9
});
var ReviewsRoute = Route$3.update({
	id: "/reviews",
	path: "/reviews",
	getParentRoute: () => Route$9
});
var WhyBrobaxRoute = Route$2.update({
	id: "/why-brobax",
	path: "/why-brobax",
	getParentRoute: () => Route$9
});
var ServicesIndexRoute = Route$1.update({
	id: "/services/",
	path: "/services/",
	getParentRoute: () => Route$9
});
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	AboutBrobexRoute,
	ContactRoute,
	FaqRoute,
	ReviewsRoute,
	WhyBrobaxRoute,
	ServicesSlugRoute: Route.update({
		id: "/services/$slug",
		path: "/services/$slug",
		getParentRoute: () => Route$9
	}),
	ServicesIndexRoute
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { BRAND as a, LuxRouteLink as c, SERVICES as d, Faq as i, NAV_LINKS as l, Route as n, LuxButton as o, getService as r, LuxLink as s, router_exports as t, Reveal as u };
