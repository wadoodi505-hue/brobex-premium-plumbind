import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PageHeader-q3pUGuA6.js
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ eyebrow, title, accent, intro, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden pt-32 pb-14 lg:pt-40 lg:pb-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "depth-bg pointer-events-none absolute inset-0",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute -top-40 left-1/2 h-[28rem] w-[28rem] -translate-x-1/2 rounded-full bg-brass/10 blur-[120px]",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "animate-in fade-in slide-in-from-bottom-4 relative mx-auto max-w-4xl px-5 text-center duration-1000 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: eyebrow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-4 text-[2.4rem] leading-[1.08] sm:text-5xl lg:text-6xl",
						children: [
							title,
							" ",
							accent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-metal",
								children: accent
							}) : null
						]
					}),
					intro ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-6 max-w-2xl text-muted-foreground",
						children: intro
					}) : null,
					children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-9",
						children
					}) : null
				]
			})
		]
	});
}
//#endregion
export { PageHeader as t };
