import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as SiteLayout } from "./SiteLayout-BFupRpb9.mjs";
import { t as PageHeader } from "./PageHeader-q3pUGuA6.mjs";
import { t as Emergency } from "./Emergency--jNbWuPk.mjs";
import { t as Testimonials } from "./Testimonials-Cb6vAj-C.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reviews-lA0Ax2N-.js
var import_jsx_runtime = require_jsx_runtime();
function ReviewsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Reviews",
			title: "The experience",
			accent: "we aim for every time",
			intro: "All reviews on this page are clearly labelled placeholder content used during development. They will be replaced with verified customer feedback once collected."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Emergency, {})
	] });
}
//#endregion
export { ReviewsPage as component };
