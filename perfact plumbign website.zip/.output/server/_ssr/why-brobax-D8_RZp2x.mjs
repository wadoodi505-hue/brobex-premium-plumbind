import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as SiteLayout } from "./SiteLayout-BFupRpb9.mjs";
import { t as PageHeader } from "./PageHeader-q3pUGuA6.mjs";
import { t as Emergency } from "./Emergency--jNbWuPk.mjs";
import { t as WhyBrobax } from "./WhyBrobax-D95JAT2w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/why-brobax-D8_RZp2x.js
var import_jsx_runtime = require_jsx_runtime();
function WhyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Why BroBax",
			title: "Three standards",
			accent: "we never move on",
			intro: "Precision, reliability, and transparency are not slogans here — they are the checks every job is measured against before we consider it finished."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhyBrobax, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Emergency, {})
	] });
}
//#endregion
export { WhyPage as component };
